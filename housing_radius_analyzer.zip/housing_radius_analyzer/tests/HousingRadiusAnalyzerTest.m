% tests/HousingRadiusAnalyzerTest.m
% =============================================================================
% Unit Tests — Housing Radius Analyzer
% Run with: runtests('tests/')  or  results = runtests('HousingRadiusAnalyzerTest')
% =============================================================================

classdef HousingRadiusAnalyzerTest < matlab.unittest.TestCase

    properties
        Analyzer
        MockLat  = 36.7473   % Bartlesville, OK
        MockLon  = -95.9700
    end

    % =========================================================================
    methods (TestMethodSetup)
        function createAnalyzer(tc)
            tc.Analyzer = HousingRadiusAnalyzer();
            tc.Analyzer.Verbose = false;
        end
    end

    % =========================================================================
    % Group 1: Haversine / geographic math
    % =========================================================================
    methods (Test, TestTags = {'geo','unit'})

        function testHaversineZeroDistance(tc)
            a = tc.Analyzer;
            d = a.haversine_public(36.0, -96.0, 36.0, -96.0);
            tc.verifyEqual(d, 0, 'AbsTol', 1e-6);
        end

        function testHaversineKnownDistance(tc)
            % Bartlesville OK to Tulsa OK — approx 46 miles
            a = tc.Analyzer;
            d = a.haversine_public(36.7473, -95.9700, 36.1540, -95.9928);
            tc.verifyGreaterThan(d, 40);
            tc.verifyLessThan(d, 55);
        end

        function testHaversine35MileRadius(tc)
            a   = tc.Analyzer;
            lat = tc.MockLat;
            lon = tc.MockLon;
            % Point exactly 35 miles north (approx 0.507 deg lat offset)
            dLat = 35 / 69;
            d    = a.haversine_public(lat, lon, lat + dLat, lon);
            tc.verifyLessThanOrEqual(d, 36);
        end

    end

    % =========================================================================
    % Group 2: locationResolver
    % =========================================================================
    methods (Test, TestTags = {'location','integration'})

        function testCityStateResolves(tc)
            loc = locationResolver('city','Bartlesville','state','OK');
            tc.verifyNotEmpty(loc.QueryLabel);
            tc.verifyEqual(loc.StateFIPS, '40');
        end

        function testZIPResolves(tc)
            loc = locationResolver('zip','74003');
            tc.verifyNotEmpty(loc.QueryLabel);
        end

        function testMetroAreaType(tc)
            loc = locationResolver('metro','Tulsa OK','areatype','developed');
            tc.verifyTrue(loc.IsMetro || isempty(loc.CBSA));
        end

        function testMissingInputThrows(tc)
            tc.verifyError(@() locationResolver(), 'locationResolver:noInput');
        end

    end

    % =========================================================================
    % Group 3: geoRadiusFilter
    % =========================================================================
    methods (Test, TestTags = {'filter','unit'})

        function testFilterRemovesOutOfRadius(tc)
            % Build a small test table with known points
            t = table();
            t.Latitude  = [36.7473; 34.0; 30.0];   % in, border, far
            t.Longitude = [-95.9700; -95.9700; -95.9700];
            t.Value     = [100; 200; 300];

            filtered = geoRadiusFilter(t, tc.MockLat, tc.MockLon, 35, 'all');
            tc.verifyEqual(height(filtered), 1);
            tc.verifyEqual(filtered.Value, 100);
        end

        function testFilterAddsDistanceColumn(tc)
            t = table();
            t.Latitude  = tc.MockLat;
            t.Longitude = tc.MockLon;
            out = geoRadiusFilter(t, tc.MockLat, tc.MockLon, 35);
            tc.verifyTrue(ismember('DistanceMiles', out.Properties.VariableNames));
        end

        function testFilterAddsGeoBin(tc)
            t = table();
            t.Latitude  = tc.MockLat + 0.05;
            t.Longitude = tc.MockLon;
            out = geoRadiusFilter(t, tc.MockLat, tc.MockLon, 35);
            tc.verifyTrue(ismember('GeoBin', out.Properties.VariableNames));
        end

        function testMissingLatLonThrows(tc)
            t = table((1:5)','VariableNames',{'Value'});
            tc.verifyError(@() geoRadiusFilter(t, 36, -96, 35), ...
                           'geoRadiusFilter:missingCol');
        end

    end

    % =========================================================================
    % Group 4: mergeHistoricalData
    % =========================================================================
    methods (Test, TestTags = {'merge','unit'})

        function testLookbackCutsOldRows(tc)
            t = table();
            t.SaleDate       = [datetime('today')-calmonths(40); datetime('today')-calmonths(5)];
            t.MedianHomeValue= [150000; 200000];
            out = mergeHistoricalData(t, 30);
            tc.verifyEqual(height(out), 1);
            tc.verifyEqual(out.MedianHomeValue, 200000);
        end

        function testMergeFlagExists(tc)
            t = table();
            t.SaleDate       = datetime('today') - caldays(10);
            t.MedianHomeValue= 175000;
            out = mergeHistoricalData(t, 30);
            tc.verifyTrue(ismember('MergeFlag', out.Properties.VariableNames));
        end

    end

    % =========================================================================
    % Group 5: xmlParser
    % =========================================================================
    methods (Test, TestTags = {'xml','unit'})

        function testParseRawXML(tc)
            xml = '<root><item><val>42</val></item></root>';
            s   = xmlParser(xml, 'output','struct');
            tc.verifyNotEmpty(s);
        end

        function testParseToBadFormatThrows(tc)
            xml = '<root/>';
            tc.verifyError(@() xmlParser(xml,'output','badformat'), 'xmlParser:badOutput');
        end

    end

    % =========================================================================
    % Group 6: setLocation + validateInputs
    % =========================================================================
    methods (Test, TestTags = {'analyzer','integration'})

        function testSetLocationPopulatesCoords(tc)
            a = tc.Analyzer;
            try
                a.setLocation('city','Tulsa','state','OK');
                % If geocoder is available, coords should be nonzero
                tc.verifyNotEqual(a.BaseLatitude,  0);
                tc.verifyNotEqual(a.BaseLongitude, 0);
            catch
                tc.assumeFail('Geocoder not reachable in this test environment.');
            end
        end

        function testRunWithoutLocationThrows(tc)
            a = HousingRadiusAnalyzer();
            a.Verbose = false;
            tc.verifyError(@() a.run(), 'HRA:noLocation');
        end

        function testSearchURLGoogle(tc)
            a   = tc.Analyzer;
            a.InputCity  = "Bartlesville";
            a.InputState = "OK";
            url = a.searchURL('engine','google');
            tc.verifyTrue(contains(url,'google.com/search'));
            tc.verifyTrue(contains(url,'residential'));
        end

        function testSearchURLBing(tc)
            a   = tc.Analyzer;
            a.InputCity  = "Tulsa";
            a.InputState = "OK";
            url = a.searchURL('engine','bing');
            tc.verifyTrue(contains(url,'bing.com/search'));
        end

    end

end
