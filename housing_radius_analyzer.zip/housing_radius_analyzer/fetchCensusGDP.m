function gdpTbl = fetchCensusGDP(countyFIPS, lookbackMonths, beaAPIKey)
% fetchCensusGDP  Pull regional GDP data from BEA and Census.gov APIs.
%
%   Inputs:
%     countyFIPS     – 5-digit county FIPS code (e.g., '40003' = Washington Co., OK)
%     lookbackMonths – Historical window in months (default: 30)
%     beaAPIKey      – BEA API key string (get free at apps.bea.gov/API/signup)
%
%   Output:
%     gdpTbl – MATLAB table with columns:
%                GeoName | Year | GDP_ThousandUSD | PerCapitaGDP |
%                Source  | GEOFIPS
%
%   Data Sources:
%     Primary  : BEA Regional Data Table CAGDP1 (Real GDP by county)
%     Secondary: BEA Table CAGDP2 (GDP by industry)
%     Fallback : Census County Business Patterns (Annual Payroll as proxy)
%
%   BEA API registration: https://apps.bea.gov/API/signup/index.cfm
%   Census API key:       https://api.census.gov/data/key_signup.html
%
%   Example:
%     gdp = fetchCensusGDP('40003', 30, 'YOUR_BEA_KEY');
% -------------------------------------------------------------------------

    if nargin < 2, lookbackMonths = 30;   end
    if nargin < 3, beaAPIKey      = '';   end

    BEA_BASE    = 'https://apps.bea.gov/api/data';
    CENSUS_BASE = 'https://api.census.gov/data';

    endYear   = year(datetime('today')) - 1;
    startYear = endYear - ceil(lookbackMonths/12) - 1;
    yearRange = strjoin(string(startYear:endYear), ',');

    % -----------------------------------------------------------------------
    % 1. BEA — CAGDP1: Real GDP (chained 2012 dollars) by county
    % -----------------------------------------------------------------------
    gdpTbl = table();

    if ~isempty(beaAPIKey)
        % All-industry total (LineCode=1)
        url = sprintf(['%s?&UserID=%s&method=GetData&datasetname=Regional' ...
                       '&TableName=CAGDP1&LineCode=1' ...
                       '&GeoFIPS=%s&Year=%s&ResultFormat=json'], ...
                       BEA_BASE, beaAPIKey, countyFIPS, yearRange);
        try
            raw    = webread(url, weboptions('Timeout',30,'ContentType','text'));
            parsed = jsondecode(raw);
            data   = parsed.BEAAPI.Results.Data;
            gdpTbl = struct2table(data,'AsArray',true);

            % Clean numeric column
            gdpTbl.DataValue = str2double(strrep(gdpTbl.DataValue,',',''));
            gdpTbl = renamevars(gdpTbl,{'DataValue'},{'GDP_ThousandUSD'});
            gdpTbl.Source(:) = "BEA_CAGDP1";

            fprintf('[fetchCensusGDP] BEA CAGDP1: %d records loaded.\n', height(gdpTbl));
        catch ME
            fprintf('[fetchCensusGDP] BEA CAGDP1 failed: %s\n', ME.message);
        end

        % Per-capita GDP — CAINC1 table
        if ~isempty(gdpTbl)
            pcURL = sprintf(['%s?&UserID=%s&method=GetData&datasetname=Regional' ...
                             '&TableName=CAINC1&LineCode=3' ...
                             '&GeoFIPS=%s&Year=%s&ResultFormat=json'], ...
                             BEA_BASE, beaAPIKey, countyFIPS, yearRange);
            try
                raw2    = webread(pcURL, weboptions('Timeout',30,'ContentType','text'));
                parsed2 = jsondecode(raw2);
                pcData  = struct2table(parsed2.BEAAPI.Results.Data,'AsArray',true);
                pcData.DataValue = str2double(strrep(pcData.DataValue,',',''));
                pcData  = renamevars(pcData,{'DataValue'},{'PerCapitaIncome_USD'});

                % Join on TimePeriod
                gdpTbl = outerjoin(gdpTbl, pcData(:,{'TimePeriod','PerCapitaIncome_USD'}), ...
                                   'Keys','TimePeriod','MergeKeys',true,'Type','left');
            catch
                gdpTbl.PerCapitaIncome_USD = nan(height(gdpTbl),1);
            end
        end
    end

    % -----------------------------------------------------------------------
    % 2. BEA GDP by industry — CAGDP2 (supplemental detail)
    % -----------------------------------------------------------------------
    if ~isempty(beaAPIKey)
        industryURL = sprintf(['%s?&UserID=%s&method=GetData&datasetname=Regional' ...
                               '&TableName=CAGDP2&LineCode=10' ...
                               '&GeoFIPS=%s&Year=%s&ResultFormat=json'], ...
                               BEA_BASE, beaAPIKey, countyFIPS, yearRange);
        try
            raw3 = webread(industryURL, weboptions('Timeout',30,'ContentType','text'));
            p3   = jsondecode(raw3);
            ind  = struct2table(p3.BEAAPI.Results.Data,'AsArray',true);
            ind.DataValue = str2double(strrep(ind.DataValue,',',''));
            fprintf('[fetchCensusGDP] BEA CAGDP2 (real estate industry): %d records.\n', height(ind));
            % Optionally attach as separate sheet — exported by exportData()
        catch
            fprintf('[fetchCensusGDP] CAGDP2 not available for this FIPS.\n');
        end
    end

    % -----------------------------------------------------------------------
    % 3. Fallback: Census County Business Patterns (annual payroll proxy)
    % -----------------------------------------------------------------------
    if isempty(gdpTbl)
        fprintf('[fetchCensusGDP] Falling back to Census County Business Patterns...\n');
        stFIPS  = countyFIPS(1:2);
        coFIPS  = countyFIPS(3:end);
        yr2     = endYear - 1;
        cbpURL  = sprintf(['%s/%d/cbp?get=PAYANN,ESTAB,NAICS2017,NAME' ...
                           '&for=county:%s&in=state:%s'], ...
                           CENSUS_BASE, yr2, coFIPS, stFIPS);
        try
            raw4   = webread(cbpURL, weboptions('Timeout',30,'ContentType','text'));
            data4  = jsondecode(raw4);
            gdpTbl = matrixToTable(data4);
            if ~isempty(gdpTbl)
                gdpTbl.PAYANN = str2double(gdpTbl.PAYANN);
                gdpTbl = renamevars(gdpTbl,{'PAYANN'},{'GDP_ThousandUSD'});
                gdpTbl.TimePeriod(:) = string(yr2);
                gdpTbl.Source(:)     = "Census_CBP_Payroll";
            end
        catch ME
            fprintf('[fetchCensusGDP] CBP fallback failed: %s\n', ME.message);
            gdpTbl = buildEmptyGDPTable();
        end
    end

    % -----------------------------------------------------------------------
    % 4. Standardise output columns
    % -----------------------------------------------------------------------
    required = {'TimePeriod','GDP_ThousandUSD','Source'};
    for i = 1:numel(required)
        if ~ismember(required{i}, gdpTbl.Properties.VariableNames)
            gdpTbl.(required{i}) = repmat("N/A", height(gdpTbl), 1);
        end
    end

    if ~ismember('GEOFIPS', gdpTbl.Properties.VariableNames)
        gdpTbl.GEOFIPS(:) = string(countyFIPS);
    end

    % Sort chronologically
    if ismember('TimePeriod', gdpTbl.Properties.VariableNames)
        gdpTbl = sortrows(gdpTbl,'TimePeriod','ascend');
    end

    fprintf('[fetchCensusGDP] Complete — %d GDP records.\n', height(gdpTbl));
end

% ---------------------------------------------------------------------------
function tbl = matrixToTable(data)
    if iscell(data) && size(data,1) > 1
        tbl = cell2table(data(2:end,:),'VariableNames',data(1,:));
    else
        tbl = table();
    end
end

function tbl = buildEmptyGDPTable()
    tbl = table(string.empty(0,1), double.empty(0,1), string.empty(0,1), string.empty(0,1), ...
                'VariableNames',{'TimePeriod','GDP_ThousandUSD','Source','GEOFIPS'});
end
