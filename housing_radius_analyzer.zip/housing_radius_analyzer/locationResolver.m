function loc = locationResolver(varargin)
% locationResolver  Resolve any combination of location identifiers into
%   a canonical struct with geocoordinates and FIPS codes.
%
%   Accepts any subset of these named parameters (case-insensitive):
%     'city'        – Municipality / city name
%     'state'       – 2-letter USPS state abbreviation  (e.g. 'OK')
%     'zip'         – 5-digit ZIP code  (e.g. '74003')
%     'township'    – Civil township name
%     'metro'       – Core Based Statistical Area (CBSA) name
%     'micro'       – Micropolitan Statistical Area name
%     'areatype'    – 'developed' | 'rural' | 'suburban'  (default: 'developed')
%
%   Output  loc  struct with fields:
%     .QueryLabel   – Human-readable string for logging / display
%     .Latitude     – WGS-84 decimal latitude
%     .Longitude    – WGS-84 decimal longitude
%     .StateFIPS    – 2-digit state FIPS code
%     .CountyFIPS   – 5-digit county FIPS code  ('' if unavailable)
%     .CBSA         – CBSA code  ('' if unavailable)
%     .AreaType     – 'developed' | 'rural' | 'suburban'
%     .IsMetro      – logical, true if CBSA is metropolitan (pop ≥ 50 000)
%     .IsMicro      – logical, true if CBSA is micropolitan (10–50 000)
%     .IsRural      – logical, true if outside any CBSA
%     .GeoJSON      – raw Nominatim JSON response (for debugging)
%
%   Example 1 — city + state:
%     loc = locationResolver('city','Bartlesville','state','OK');
%
%   Example 2 — ZIP only:
%     loc = locationResolver('zip','74003');
%
%   Example 3 — metropolitan area:
%     loc = locationResolver('metro','Tulsa-Muskogee-Bartlesville');
%
%   Example 4 — township:
%     loc = locationResolver('township','Caney Valley','state','OK');
%
%   Example 5 — rural micro:
%     loc = locationResolver('micro','Bartlesville OK','areatype','rural');
% -------------------------------------------------------------------------

    p = inputParser;
    addParameter(p,'city',     '',         @(x)ischar(x)||isstring(x));
    addParameter(p,'state',    '',         @(x)ischar(x)||isstring(x));
    addParameter(p,'zip',      '',         @(x)ischar(x)||isstring(x));
    addParameter(p,'township', '',         @(x)ischar(x)||isstring(x));
    addParameter(p,'metro',    '',         @(x)ischar(x)||isstring(x));
    addParameter(p,'micro',    '',         @(x)ischar(x)||isstring(x));
    addParameter(p,'areatype', 'developed',@(x)ischar(x)||isstring(x));
    parse(p, varargin{:});

    city      = strtrim(char(p.Results.city));
    state     = upper(strtrim(char(p.Results.state)));
    zip       = strtrim(char(p.Results.zip));
    township  = strtrim(char(p.Results.township));
    metro     = strtrim(char(p.Results.metro));
    micro     = strtrim(char(p.Results.micro));
    areatype  = lower(strtrim(char(p.Results.areatype)));

    % Initialise output
    loc = struct(...
        'QueryLabel',  '', ...
        'Latitude',    0,  ...
        'Longitude',   0,  ...
        'StateFIPS',   '', ...
        'CountyFIPS',  '', ...
        'CBSA',        '', ...
        'AreaType',    areatype, ...
        'IsMetro',     false, ...
        'IsMicro',     false, ...
        'IsRural',     false, ...
        'GeoJSON',     struct());

    % -----------------------------------------------------------------------
    % Build query string — priority: ZIP > city+state > township > metro/micro
    % -----------------------------------------------------------------------
    if ~isempty(zip)
        queryStr        = zip;
        loc.QueryLabel  = zip;
        if ~isempty(state), loc.QueryLabel = [zip ', ' state]; end
    elseif ~isempty(city) && ~isempty(state)
        queryStr        = [city ', ' state ', USA'];
        loc.QueryLabel  = [city ', ' state];
    elseif ~isempty(city)
        queryStr        = [city ', USA'];
        loc.QueryLabel  = city;
    elseif ~isempty(township) && ~isempty(state)
        queryStr        = [township ' Township, ' state ', USA'];
        loc.QueryLabel  = [township ' Township, ' state];
    elseif ~isempty(metro)
        queryStr        = [metro ' Metropolitan Area, USA'];
        loc.QueryLabel  = [metro ' MSA'];
        loc.IsMetro     = true;
    elseif ~isempty(micro)
        queryStr        = [micro ' Micropolitan Area, USA'];
        loc.QueryLabel  = [micro ' μSA'];
        loc.IsMicro     = true;
    else
        error('locationResolver:noInput', ...
              'Supply at least one of: city, state, zip, township, metro, micro.');
    end

    % -----------------------------------------------------------------------
    % Geocode via Nominatim
    % -----------------------------------------------------------------------
    nomURL = sprintf('https://nominatim.openstreetmap.org/search?q=%s&format=json&limit=1&countrycodes=us', ...
                     urlencode(queryStr));
    opts   = weboptions('Timeout',15,'ContentType','text', ...
                        'HeaderFields',{'User-Agent','locationResolver/1.0 (MATLAB)'});
    try
        raw         = webread(nomURL, opts);
        nomData     = jsondecode(raw);
        loc.GeoJSON = nomData;

        if ~isempty(nomData)
            loc.Latitude  = str2double(nomData(1).lat);
            loc.Longitude = str2double(nomData(1).lon);
            fprintf('[locationResolver] Geocoded "%s" → (%.5f, %.5f)\n', ...
                    loc.QueryLabel, loc.Latitude, loc.Longitude);
        else
            warning('locationResolver:noResult','Nominatim returned no results for: %s', queryStr);
        end
    catch ME
        warning('locationResolver:nominatimFail','Nominatim error: %s', ME.message);
        % Attempt Census Geocoder fallback
        loc = geocodeCensusFallback(loc, queryStr, city, state, zip);
    end

    % -----------------------------------------------------------------------
    % Resolve FIPS via Census Geocoder
    % -----------------------------------------------------------------------
    if ~isempty(state)
        loc.StateFIPS = stateFIPSfromAbbrev(state);
    end

    if loc.Latitude ~= 0 && loc.Longitude ~= 0
        loc.CountyFIPS = resolveCountyFIPS(loc.Latitude, loc.Longitude);
    end

    % -----------------------------------------------------------------------
    % Classify area type from CBSA data (Census)
    % -----------------------------------------------------------------------
    if ~isempty(loc.CountyFIPS)
        [loc.CBSA, cbsaType] = lookupCBSA(loc.CountyFIPS);
        switch lower(cbsaType)
            case 'metropolitan statistical area'
                loc.IsMetro  = true;
                if strcmp(areatype,'developed'), loc.AreaType = 'developed'; end
            case 'micropolitan statistical area'
                loc.IsMicro  = true;
                if strcmp(areatype,'developed'), loc.AreaType = 'suburban'; end
            otherwise
                loc.IsRural  = true;
                if strcmp(areatype,'developed'), loc.AreaType = 'rural'; end
        end
    end

    fprintf('[locationResolver] Resolved: %s | AreaType: %s | StateFIPS: %s | CountyFIPS: %s\n', ...
            loc.QueryLabel, loc.AreaType, loc.StateFIPS, loc.CountyFIPS);
end

% ===========================================================================
%  Internal helpers
% ===========================================================================

function loc = geocodeCensusFallback(loc, ~, city, state, zip)
    base = 'https://geocoding.geo.census.gov/geocoder/locations/';
    if ~isempty(zip) && ~isempty(state)
        url = sprintf('%saddress?city=%s&state=%s&zip=%s&benchmark=Public_AR_Current&format=json', ...
                      base, urlencode(city), state, zip);
    elseif ~isempty(city) && ~isempty(state)
        url = sprintf('%sonelineaddress?address=%s+%s&benchmark=Public_AR_Current&format=json', ...
                      base, urlencode(city), state);
    else
        return
    end
    try
        raw  = webread(url, weboptions('Timeout',15,'ContentType','text'));
        data = jsondecode(raw);
        m    = data.result.addressMatches;
        if ~isempty(m)
            loc.Latitude  = m(1).coordinates.y;
            loc.Longitude = m(1).coordinates.x;
            fprintf('[locationResolver] Census geocoder fallback succeeded.\n');
        end
    catch
        fprintf('[locationResolver] Census geocoder fallback also failed.\n');
    end
end

function fips = resolveCountyFIPS(lat, lon)
    url = sprintf(['https://geo.fcc.gov/api/census/block/find' ...
                   '?latitude=%.6f&longitude=%.6f&format=json'], lat, lon);
    try
        raw  = webread(url, weboptions('Timeout',10,'ContentType','text'));
        data = jsondecode(raw);
        fips = data.County.FIPS;
    catch
        fips = '';
    end
end

function [cbsaCode, cbsaType] = lookupCBSA(countyFIPS)
% Uses Census TIGER REST API to get CBSA classification for a county.
    url = sprintf(['https://tigerweb.geo.census.gov/arcgis/rest/services/' ...
                   'TIGERweb/CBSA/MapServer/0/query' ...
                   '?where=COUNTYFP=%s&outFields=CBSAFP,LSAD&f=json'], ...
                   countyFIPS(3:end));
    try
        raw  = webread(url, weboptions('Timeout',10,'ContentType','text'));
        data = jsondecode(raw);
        if ~isempty(data.features)
            cbsaCode = data.features(1).attributes.CBSAFP;
            lsad     = data.features(1).attributes.LSAD;
            if strcmp(lsad,'M1')
                cbsaType = 'Metropolitan Statistical Area';
            elseif strcmp(lsad,'M2')
                cbsaType = 'Micropolitan Statistical Area';
            else
                cbsaType = 'Rural';
            end
        else
            cbsaCode = '';
            cbsaType = 'Rural';
        end
    catch
        cbsaCode = '';
        cbsaType = '';
    end
end

function fips = stateFIPSfromAbbrev(abbrev)
    map = containers.Map( ...
        {'AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID', ...
         'IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS', ...
         'MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK', ...
         'OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV', ...
         'WI','WY','DC'}, ...
        {'01','02','04','05','06','08','09','10','12','13','15','16', ...
         '17','18','19','20','21','22','23','24','25','26','27','28', ...
         '29','30','31','32','33','34','35','36','37','38','39','40', ...
         '41','42','44','45','46','47','48','49','50','51','53','54', ...
         '55','56','11'});
    a = upper(strtrim(abbrev));
    if isKey(map, a), fips = map(a); else, fips = ''; end
end
